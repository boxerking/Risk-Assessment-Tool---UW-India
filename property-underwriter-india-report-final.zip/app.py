import streamlit as st
from utils.elevation_utils import get_elevation, classify_flood_risk
from utils.exposure_utils import get_nearby_exposures
from utils.pdf_utils import generate_pdf_report
import tempfile
import os

st.set_page_config(page_title="AI Property Underwriter - India", layout="wide")
st.title("🏠 AI Property Underwriting Tool - India")
st.markdown("Enter coordinates to assess risk and generate a printable PDF report.")

col1, col2 = st.columns(2)
with col1:
    lat = st.number_input("Latitude", value=28.6139, format="%.6f")
with col2:
    lon = st.number_input("Longitude", value=77.2090, format="%.6f")

if st.button("Analyze & Generate Report"):
    st.subheader("📊 Risk Assessment Summary")

    elevation = get_elevation(lat, lon)
    flood_risk = classify_flood_risk(elevation)
    exposure_count, exposures = get_nearby_exposures(lat, lon)

    st.markdown(f"**Elevation:** {elevation if elevation is not None else 'Unavailable'} m")
    st.markdown(f"**Urban Flood Risk:** {flood_risk}")
    st.markdown(f"**Nearby Fire-prone Units:** {exposure_count}")

    # Prepare data for PDF
    report_data = {
        "Coordinates": f"Latitude: {lat}, Longitude: {lon}",
        "Elevation": f"{elevation if elevation is not None else 'Unavailable'} m",
        "Urban Flood Risk": flood_risk,
        "Borrowed Fire Exposure": f"{exposure_count} hazardous facilities nearby"
    }

    # Generate PDF in a temporary file
    tmp_pdf = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    generate_pdf_report(report_data, tmp_pdf.name)

    with open(tmp_pdf.name, "rb") as f:
        st.download_button(
            label="📄 Download PDF Report",
            data=f,
            file_name="underwriting_report.pdf",
            mime="application/pdf"
        )

    os.unlink(tmp_pdf.name)